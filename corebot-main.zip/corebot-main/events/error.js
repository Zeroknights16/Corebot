module.exports = async (bot, err) => {
    console.log(`${require("../modules/utils").errorPrefix}${err}`);
}
// 203265   8501   2228469    63250   1622514811   5ca616571bef5cf6cc5dc5f13623f65d70d8022f   2228469