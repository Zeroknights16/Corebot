const Utils = require("../modules/utils");

module.exports = async (bot, invite) => {
    Utils.updateInviteCache(bot)
}
// 203265   8501   2228469    63250   1622514811   5ca616571bef5cf6cc5dc5f13623f65d70d8022f   2228469